var searchData=
[
  ['boolean',['boolean',['../de/d21/a00006_a5f04b715119204d777d92db5c3af8fd2.html#a5f04b715119204d777d92db5c3af8fd2',1,'json::Var']]]
];
