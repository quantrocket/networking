var searchData=
[
  ['groups',['groups',['../d2/de7/a00014_ada67ae096c0aa4bddfa7193f1109ddb0.html#ada67ae096c0aa4bddfa7193f1109ddb0',1,'net::Worker::groups()'],['../d7/dec/a00010_a76ea7c66b9366a382b7beb709d6af4b0.html#a76ea7c66b9366a382b7beb709d6af4b0',1,'net::Server::groups()']]],
  ['groups_5fmutex',['groups_mutex',['../d7/dec/a00010_adf261f4967693c1e9c4993d85fe30888.html#adf261f4967693c1e9c4993d85fe30888',1,'net::Server']]]
];
