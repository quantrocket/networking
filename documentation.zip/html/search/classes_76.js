var searchData=
[
  ['var',['Var',['../de/d21/a00006.html',1,'json']]]
];
