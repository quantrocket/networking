var searchData=
[
  ['sender',['sender',['../d7/dec/a00010_a18ba3fa9e4ebfb6ea2801f3e61f4adef.html#a18ba3fa9e4ebfb6ea2801f3e61f4adef',1,'net::Server']]],
  ['server',['server',['../d2/de7/a00014_a69593ef3c4879c6beff5e89af6f6ed6a.html#a69593ef3c4879c6beff5e89af6f6ed6a',1,'net::Worker']]],
  ['set',['set',['../da/d45/a00011_a5ccfb4ff9a2e2488ad3569f89600d930.html#a5ccfb4ff9a2e2488ad3569f89600d930',1,'net::tcp::Link']]],
  ['socket',['socket',['../da/d45/a00011_a0e7707282322464c985562dd33da4f4e.html#a0e7707282322464c985562dd33da4f4e',1,'net::tcp::Link::socket()'],['../df/d86/a00012_a4b814d8c3b73a8f0748b8868ed6649ac.html#a4b814d8c3b73a8f0748b8868ed6649ac',1,'net::tcp::Listener::socket()']]],
  ['string',['string',['../de/d21/a00006_a52841b18c23e7639da26549b13ce4176.html#a52841b18c23e7639da26549b13ce4176',1,'json::Var']]]
];
