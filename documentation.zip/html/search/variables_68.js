var searchData=
[
  ['handler',['handler',['../d4/dee/a00008_a492cdf3746477b60476ef11b05fc367c.html#a492cdf3746477b60476ef11b05fc367c',1,'net::Client::handler()'],['../d7/dec/a00010_a20805f476356d5a9c651a70cbe0bcb0e.html#a20805f476356d5a9c651a70cbe0bcb0e',1,'net::Server::handler()']]]
];
