var searchData=
[
  ['type',['type',['../de/d21/a00006_a10a4be4edd18bef58328ea3dacb24c26.html#a10a4be4edd18bef58328ea3dacb24c26',1,'json::Var']]]
];
