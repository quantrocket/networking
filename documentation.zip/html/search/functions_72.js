var searchData=
[
  ['read',['read',['../da/d45/a00011_afa2e7cedddf32705fdf99cfd41d0a60f.html#afa2e7cedddf32705fdf99cfd41d0a60f',1,'net::tcp::Link']]],
  ['recv_5floop',['recv_loop',['../d7/dec/a00010_a7ea2d0802f3d055d7b480c7d3176cc8c.html#a7ea2d0802f3d055d7b480c7d3176cc8c',1,'net::Server']]],
  ['request_5flogin',['request_login',['../d1/d7c/a00003_ac6765bc1fb57433311c2c6738da06f0b.html#ac6765bc1fb57433311c2c6738da06f0b',1,'ChatClient']]],
  ['request_5flogout',['request_logout',['../d1/d7c/a00003_af0bfbddac42975e19c91558c8c6ddc29.html#af0bfbddac42975e19c91558c8c6ddc29',1,'ChatClient::request_logout()'],['../d0/d0b/a00004_a69c08806ff92f9092433f6f0f4a40f0c.html#a69c08806ff92f9092433f6f0f4a40f0c',1,'ChatServer::request_logout()']]],
  ['request_5fmessage',['request_message',['../d1/d7c/a00003_a7c3d69bbd7700e8fdc660860571fdc97.html#a7c3d69bbd7700e8fdc660860571fdc97',1,'ChatClient']]]
];
