var searchData=
[
  ['networker',['networker',['../d4/dee/a00008_a5175c4136afc73d85e504a0555d3bac7.html#a5175c4136afc73d85e504a0555d3bac7',1,'net::Client']]],
  ['next_5fid',['next_id',['../d7/dec/a00010_aa58a125184a5f704078ce903b7f84ec2.html#aa58a125184a5f704078ce903b7f84ec2',1,'net::Server']]]
];
