var searchData=
[
  ['boolean',['BOOLEAN',['../df/d61/a00031_a5858e94f4d3ee83647ef32c7ab64f437.html#a5858e94f4d3ee83647ef32c7ab64f437a3c4ffa708ab93f0c120a54a70210aafa',1,'json']]]
];
